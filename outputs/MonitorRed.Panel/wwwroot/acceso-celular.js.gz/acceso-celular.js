fetch('/api/mobile/access', { cache: 'no-store' }).then(r => r.json()).then(data => {
  document.getElementById('code').textContent = data.code;
  const link = document.getElementById('link');
  if (data.mode === 'private-vpn' && /^http:\/\/10\.[0-9.]+:5081\/$/.test(data.url)) { link.textContent = data.url; link.href = data.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; }
  else link.textContent = 'Acceso VPN pendiente de configuración.';
  document.getElementById('vpnState').textContent = data.listeningOnVpn ? 'Vision está escuchando en la interfaz VPN. Confirma el acceso desde el celular.' : 'La interfaz VPN no estaba disponible al iniciar Vision. Conecta la VPN y reinicia Vision.';
}).catch(() => { document.getElementById('code').textContent = 'No se pudo consultar el acceso.'; });
